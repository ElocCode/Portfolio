# sp22-lab3
Please read the Lab3 ReadMe pdf
