//CMPSC 311 SP22
//LAB 2

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include "mdadm.h"
#include "jbod.h"

int mounted = 0;

//using op disk id and block id it will form them into a uint32 binary in there repective order to be used for operations
uint32_t packedbytes(uint32_t op, uint32_t diskID, uint32_t reserved, uint32_t blockID) {
  uint32_t returnVal;

  uint32_t tempa = blockID;
  uint32_t tempb = reserved << 8;
  uint32_t tempc = diskID << 22;
  uint32_t tempd = op << 26;
  returnVal = tempa | tempb | tempc | tempd;

  return returnVal;
}

//using address gives the disk id 
int diskID(uint32_t addr){
  int id;
  int diskLen = 256*256;
  id = addr / diskLen;
  return id;
}

//using address gives the block id
int blockID (uint32_t addr){
  int id = addr/256;
  return id;
}

//will mount all discs
int mdadm_mount(void) {
  uint32_t op = packedbytes(0,0,0,0);
  int x;
  x = jbod_operation(op,NULL);
  if(x == 0){
    mounted = 1;
    return 1;
  }
  return -1;
}

//will unmount all discs
int mdadm_unmount(void) {
  uint32_t op = packedbytes(1,0,0,0);
  int x;
  x = jbod_operation(op,NULL);
  if(x == 0){
    mounted = 0;
    return 1;
  }
  else{
    return -1;
  }
}

//given the address, buffer and len it will copy all information for the corresponding bytes on the disks to the buffer using temporary buffers
int mdadm_read(uint32_t addr, uint32_t len, uint8_t *buf) {
  if(len > 1024 || len < 0 || mounted == 0 ||addr < 0 || addr+len > (16*(256*256)) || (buf == NULL && len!=0)){
    return -1;
  }
  
  uint8_t wholeBuf[len];
  memset(wholeBuf, 0, len);

  //after creating a all 0 buffer I then seek out the first disk needed to be copied
  int start = addr % 256;
  int readBytes = 0;
  uint32_t op = packedbytes(2,diskID(addr),0,blockID(addr));
  jbod_operation(op,NULL);
  op = packedbytes(3,diskID(addr),0,blockID(addr));
  jbod_operation(op,NULL);

  //I then created another temporary buffer to act as the first iteration of the whole buffer seperating it just incase the whole block isnt called on and only part of it.
  uint8_t tempBuf[256];
  memset(tempBuf, 0, 256);
  op = packedbytes(4,diskID(addr),0,blockID(addr));
  jbod_operation(op,tempBuf);

  int currentDisk = diskID(addr);

  int incer;
  if(addr + len < 256){
    incer = len;
  }
  else{
    incer = 256 - start;
  }
  memcpy(&wholeBuf[readBytes],&tempBuf[start], incer);
  readBytes += incer;

  addr += 256;

  
  
  //A while loop to loop through the rest of the blocks and disks in the len and copy information onto the whole buffer
  while(readBytes < len){
    //checks if a new disk is being used and will seek out the starting block in it
    if(currentDisk != diskID(addr)){
      uint32_t op = packedbytes(2,diskID(addr),0,blockID(addr));
      jbod_operation(op,NULL);
      op = packedbytes(3,diskID(addr),0,blockID(addr));
      jbod_operation(op,NULL);
      currentDisk++;
    }
    //checks if the end is not a full 256 block and will prevent overflow when memcpy to the whole buffer
    if(len - readBytes < 256){
      incer = len - readBytes;
    }
    else{
      incer = 256;
    }

    uint8_t tempBuf2[256];
    memset(tempBuf2, 0, 256);
    op = packedbytes(4,diskID(addr),0,blockID(addr));
    jbod_operation(op,tempBuf2);
    

    memcpy(&wholeBuf[readBytes],tempBuf2,incer);

    //increments readBytes and addr to keep track of placement in blocks and discs
    if(len - readBytes >= 256){
      readBytes += 256;
    }
    else{
      readBytes = len;
    }
    addr += 256;
  }
  //copies whole buffer onto the return buffer
  memcpy(buf, wholeBuf, len);
  
  return len;
}
