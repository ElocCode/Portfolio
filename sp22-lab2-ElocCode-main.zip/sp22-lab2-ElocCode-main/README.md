# SP22-lab2
Checkout Readme_LAB2.pdf
