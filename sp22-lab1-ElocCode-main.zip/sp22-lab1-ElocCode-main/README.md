# Lab 1 
This repositary contains the started code for Lab 1
Please refer to readme_lab1.pdf for details.

