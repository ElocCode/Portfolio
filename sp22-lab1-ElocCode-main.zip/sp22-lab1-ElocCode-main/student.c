#include "student.h"
#include <stdbool.h>


/* Lab- 1 Due by 11th Feb 2022
   Make sure your code looks clean
   Write comments with your code
   Do not foget to 'push' your code github reglarly
   */
   
//manual math.pow implementation
int power(int number, int x){
	int product = 1;
	while (x > 0){
		product *= number;
		x--;
	}
	return product;
}

// Takes an array of integers and the length of the array as input, and returns the smallest integer in the array
int smallest(int array[], int length) {
	// Function Body
	int min = array[0];
	for(int i = 1; i<length; i++ ){
		if(array[i] < min ){
			min = array[i];
		}
	}
	return min;
	}
	
// Takes an array of integers and the length of the array as input, and returns the sum of the integers in the array.
int sum(int array[], int length)  {
	// Function Body
	int sum = 0;
	for(int i = 0; i<length; i++ ){
		sum += array[i];
	}
	return sum;
	}
	
// Takes pointers to two integers and swaps the values of integers
void swap(int *a, int *b) {
	// Function Body
	int temp = *a;
	*a = *b;
	*b = temp;
	}

// Rotate values of integers
void rotate(int *a, int *b, int *c){
	// Function Body
	int temp = *a;
	*a = *c;
	*c = *b;
	*b = temp;
	}

// Sorts an array in descending order 
void sort(int array[], int length){
	// Function Body
	bool flip = true;
	while (flip == true) {
		flip = false;
		//set the loop to go till before the last value in the array so when checking the value infront of the current we wont go out of bounds
		for (int i = 0; i < length-1; i++){
			int *p, *q;
			p = &array[i];
			q = &array[i+1];
			if (*p < *q){
				swap(p, q);
				flip = true;
			}
		}
	}
	}
	
//Takes an array of integers and the length of the array as input and cubes  every prime element of the array
void cube_primes(int array[], int length){
	// Function Body
	for(int i = 0; i<length; i++ ){
		bool checker = true;
		int *p = &array[i];
		//This loop will check if the number is not a prime and change the boolean to false meaning it is not prime
		for(int x = 2; x<=array[i]/2; x++){
			if(array[i] % x == 0){
				checker = false;
			}
		}
		//This will sort out any negative, 1, or 0 since they cant be prime
		if(array[i] == 0 || array[i] == 1 || array[i] < 0){
		}
		else{
			if(checker == true){
				*p = power(array[i], 3);
			}
			
		}
	}
	}

// Takes an array of integers and the length of the array as input and double every positive element of the array that is an Armstrong number. 
void double_armstrongs(int array[], int length) {
	// Function Body
	for(int i = 0; i<length; i++ ){
		int current = array[i];
		int armstrong = 0;
		int count = 0;
		//counts the amount of numbers in the value to see what power it must go to
		while(current!=0){
			current/=10;
			count++;
		}
		//this will check if the number is an armstrong number by using the armstrong formula
		current = array[i];
		while(current>0){
			armstrong += power(current%10, count);
			current/=10;
		}
		int *p = &array[i];
		if (armstrong == array[i] && array[i] >= 0){
			*p *= 2;
		}
	}
	}
	
//Take an array of integers and length of the arrays as input and negate every happy number of that array
void negate_happy(int array[], int length){
	// Function Body
	for(int i = 0; i < length; i++ ){
		int current = array[i];
		int happy = 0;
		//will check any positive value that could be a happy value. while looping through it checks if happy is every 1 or 4 meaning that if its 1 its happy and if its 4 its unhappy.
		if(array[i] > 0){
			while(happy != 4 && happy != 1){
				happy = 0;
				while (current>0){
					happy += power(current%10, 2);
					current/=10;
				}
				current = happy;
			}
			int *p = &array[i];
			if (happy == 1){
				*p *= -1;
			}
		}
		
	}
	}


