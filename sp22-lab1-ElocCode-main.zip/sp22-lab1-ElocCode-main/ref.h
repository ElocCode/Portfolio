#include <stdbool.h>


 int ref_smallest(int array[], int length);
 int ref_sum(int array[], int length) ;
 void ref_swap(int *a, int *b);
 void ref_rotate(int *a, int *b, int *c);
 void ref_sort(int array[], int length);
 void ref_cube_primes(int array[], int length);
 void ref_double_armstrongs(int array[], int length) ;
 void ref_negate_happy(int array[], int length);
