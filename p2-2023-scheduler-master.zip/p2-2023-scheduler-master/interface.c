#include "interface.h"
#include "scheduler.h"

// Interface implementation
// ensure that you have all the threads in the queue then make all the decisions
// global variables

int thread_amount;
int current_threads = 0;
pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t c;

void init_scheduler(int thread_count) {
    // TODO: Implement this
    thread_amount = thread_count;
    init_Q();
}

int cpu_me(float current_time, int tid, int remaining_time) {
   	 // TODO: Implement this
   	 // how to tell which thread is which
   	 // goal: run for multiple threads current_time is task arrival 
   	 // while loop till all threads are set in queue 
   	 //1 wait for all threads
   	 //2 wait untill its your turn
   	 //3 when running time is 0 wake everyone else up
   	 
   	 pthread_mutex_lock(&m);
   	 list_entry_t *frame;
   	 if(!find_tid(tid)){
   	 	current_threads++;
   	 	update_Q(current_time, tid, remaining_time);
   	 }
   	 //wait for all threads to be in
   	 if(current_threads==thread_amount){
   	 	pthread_cond_broadcast(&c);
   	 	if(debug(2)){printf("%d released threads\n", tid);}
   	 }else{
   	 	if(debug(2)){printf("%d is waiting for all threads \t CTHREADS: %d\n", tid, current_threads);}
   	 	pthread_cond_wait(&c, &m);
   	}
   	if(debug(2)){printf("%d is free\n", tid);}
   	 
   	//Wait until it is THIS threads time
   	int turn = find_next();
   	reloop:
   	while(turn==-1){
   		if(debug(5)){printf("%d can't find ready \t\t TIME: %d->%d\n", tid, global_time, global_time+1);}
   		global_time++;
   		turn = find_next();
   	}
   	while(turn!=tid){
   		if(debug(2)){printf("%d waiting for turn \t\t TURN: %d\n", tid, turn);}
   		pthread_cond_broadcast(&c);
   		pthread_cond_wait(&c, &m);
   		turn = find_next();
   		if(turn==-1){goto reloop;}
   	}
   	pthread_cond_broadcast(&c);
 	if(remaining_time){global_time++;}
 	if(debug(2)){printf("%d completed cycle\n", tid);}
 	update_entry(tid, remaining_time-1);
 	pthread_mutex_unlock(&m);
	return global_time;
}

int io_me(float current_time, int tid, int device_id) {
    // TODO: Implement this
    //AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
    return 0;
}

void end_me(int tid) {
    // TODO: Implement this
    free(pop(tid));
    thread_amount--;
    current_threads--;
    if(debug(2)){printf("%d is done\n", tid);}
}
