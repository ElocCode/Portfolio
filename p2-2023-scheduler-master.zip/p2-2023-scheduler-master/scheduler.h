/*
 * Utilize "scheduler.h" and "scheduler.c" for all the utility functions students
 * intend to use for "interface.c".
 */
#ifndef SCHEDULER_H
#define SCHEDULER_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include <limits.h>
#include <pthread.h>

#include "interface.h"

typedef struct sched_entry entry_t;
typedef struct list_entry list_entry_t;
typedef struct list list_t;
extern unsigned int global_time;
extern list_entry_t * find_tid(int tid);
extern int init_Q();
extern int update_Q(float c_time, unsigned int tid, int burst_time);
extern int update_entry(int tid, int rem_time);
extern list_entry_t * find_tid(int tid);
extern int find_next();
extern entry_t * pop(int tid);
extern int debug(int n);

extern int sched_mode;


#endif
