#include "scheduler.h"

// TODO: Add your function definitions here.
unsigned int global_time = 0;
int sched_mode = 1;
int debug_mode = 0;

typedef struct sched_entry{
	unsigned int time;
	int tid;
	unsigned int burst;
}entry_t;

typedef struct list_entry{
	entry_t *entry;
	list_entry_t *next;
	list_entry_t *prev;
}list_entry_t;

typedef struct list {
	list_entry_t *head;
} list_t;

list_t *frame_list;

int init_Q(){
	//printf("initiate queue...\n");
	frame_list = (list_t *)malloc(sizeof(list_t));
	frame_list->head = NULL;
  	return 0;
}

int update_Q(float c_time, unsigned int tid, int burst_time)
{
  	//general purpose updater places new entries at end
  	
  	entry_t *task_entry = (entry_t *)malloc(sizeof(entry_t));
  	task_entry->time = (int)ceilf(c_time);
  	if(debug(3)){printf("%d: time = %d\n", tid, task_entry->time);}
  	task_entry->tid = tid;
  	task_entry->burst = burst_time;
  	
  	list_entry_t *made = (list_entry_t *)malloc(sizeof(list_entry_t));
  	made->entry = task_entry;
  	made->next = made;
  	made->prev = made;
  	
  	/* put it at the end of the list (beginning if null) */
  	if ( frame_list->head == NULL ) {frame_list->head = made;}
  	/* or really at end */
  	else {
   		made->next = frame_list->head;
   		made->prev = frame_list->head->prev;
   		frame_list->head->prev->next = made;
   		frame_list->head->prev = made;
  	}
  	return 0;  
}

int update_entry(int tid, int rem_time){
	list_entry_t *frame = find_tid(tid);
	if(!frame){return 0;}
	frame->entry->burst = rem_time;
	return 1;
}

list_entry_t* find_tid(int tid){
	//Is tid already scheduled? If so, return a pointer to the list_entry
	if(!frame_list->head){return NULL;}
	list_entry_t *pointer = frame_list->head;
	do{	if(pointer->entry->tid==tid){return pointer;}
		pointer = pointer->next;
	}while(frame_list->head!=pointer);
	return NULL;
}

int ready(entry_t *entry){
	//Has entry arrived yet?
	return (entry->time<=global_time)?1:0;
}

int one_ready(){
	//Has any entry arrived yet?
	list_entry_t *pointer = frame_list->head;
	if(debug(5)){printf("Is an entry ready?\t\t");}
	do{
		if(ready(pointer->entry)){
			if(debug(5)){printf("Yes tid:%d\n", pointer->entry->tid);}
			return 1;
		}
		pointer = pointer->next;
	}while(pointer!=frame_list->head);
	if(debug(5)){printf("No\n");}
	return 0;
}


int find_fifo(){
	//returns tid of fifo
	//M: keep an eye on this, it doesn't check if the entry has arrived.
	list_entry_t *pointer = frame_list->head;
	entry_t *victim = pointer->entry;
	do{
		if(pointer->entry->time<victim->time){victim = pointer->entry;}
		else if(pointer->entry->time==victim->time){
			if(pointer->entry->tid<victim->tid){victim = pointer->entry;}
		}
		pointer = pointer->next;
	}while(frame_list->head!=pointer);
	return victim->tid;
}

int find_strf(){
	//returns tid of srtf
	list_entry_t *pointer = frame_list->head;
	while(!ready(pointer->entry)){pointer = pointer->next;}
	entry_t *victim = pointer->entry;
	if(debug(3)){printf("Start STRF:\t Time:%d\n\thead:%d, b:%d\n", global_time, victim->tid, victim->burst);}
	do{
		if(debug(3)){printf("\tCheck:%d, b:%d t:%d\n", pointer->entry->tid, pointer->entry->burst, pointer->entry->time);}
		if(pointer->entry->burst<victim->burst){
			if(ready(pointer->entry)){victim = pointer->entry;}
		}else if(pointer->entry->burst==victim->burst){
			if(debug(3)){printf("\tRace, %d %d\n", victim->tid, pointer->entry->tid);}
			if(pointer->entry->tid<victim->tid){
				if(ready(pointer->entry)){victim = pointer->entry;}
			}
		}
		if(debug(3)){printf("\tVictim:%d, b:%d\n", victim->tid, victim->burst);}
		pointer = pointer->next;
	}while(frame_list->head!=pointer);
	return victim->tid;
}

int find_next(){
	//returns tid of next frame to be eliminated
	if(!one_ready()){return -1;}
	return sched_mode ? find_strf() : find_fifo();
}


entry_t * pop(int tid){
	//remove the entry with the tid from the queue
	list_entry_t *vict = find_tid(tid);
	if(!vict){return NULL;}
	if(vict==frame_list->head){
		if(frame_list->head==frame_list->head->next){frame_list->head=NULL;}
		else{frame_list->head = frame_list->head->next;}
	}
	vict->prev->next = vict->next;
	vict->next->prev = vict->prev;
	entry_t *victim = vict->entry;
	free(vict);
	return victim;
}

int debug(int n){
	if(!debug_mode){return 0;}
	if(debug_mode%n==0){return 1;}
	return 0;
}

int find_maidens(){
	return 0;
}
