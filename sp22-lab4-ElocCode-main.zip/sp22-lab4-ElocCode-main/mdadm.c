#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <stdlib.h>

#include "mdadm.h"
#include "jbod.h"


int mounted = 0;

//using op disk id and block id it will form them into a uint32 binary in there repective order to be used for operations
uint32_t packedbytes(uint32_t op, uint32_t diskID, uint32_t reserved, uint32_t blockID) {
  uint32_t returnVal;

  uint32_t tempa = blockID;
  uint32_t tempb = reserved << 8;
  uint32_t tempc = diskID << 22;
  uint32_t tempd = op << 26;
  returnVal = tempa | tempb | tempc | tempd;

  return returnVal;
}

//using address gives the disk id 
int diskID(uint32_t addr){
  int id;
  int diskLen = 256*256;
  id = addr / diskLen;
  return id;
}

//using address gives the block id
int blockID (uint32_t addr){
  int id = (addr/256)%256;
  return id;
}

//will mount all discs
int mdadm_mount(void) {
  uint32_t op = packedbytes(0,0,0,0);
  int x;
  x = jbod_operation(op,NULL);
  if(x == 0){
    mounted = 1;
    return 1;
  }
  return -1;
}

//will unmount all discs
int mdadm_unmount(void) {
  uint32_t op = packedbytes(1,0,0,0);
  int x;
  x = jbod_operation(op,NULL);
  if(x == 0){
    mounted = 0;
    return 1;
  }
  else{
    return -1;
  }
}

//given the address, buffer and len it will copy all information for the corresponding bytes on the disks to the buffer using temporary buffers
int mdadm_read(uint32_t addr, uint32_t len, uint8_t *buf) {
  if(len > 1024 || len < 0 || mounted == 0 ||addr < 0 || addr+len > (16*(256*256)) || (buf == NULL && len!=0)){
    return -1;
  }
  
 

  uint8_t wholeBuf[len];
  memset(wholeBuf, 0, len);

  //after creating a all 0 buffer I then seek out the first disk needed to be copied
  int start = addr % 256;
  int readBytes = 0;
  uint32_t op = packedbytes(2,diskID(addr),0,blockID(addr));
  jbod_operation(op,NULL);
  op = packedbytes(3,diskID(addr),0,blockID(addr));
  jbod_operation(op,NULL);

  //I then created another temporary buffer to act as the first iteration of the whole buffer seperating it just incase the whole block isnt called on and only part of it.
  uint8_t tempBuf[256];
  memset(tempBuf, 0, 256);
  op = packedbytes(4,diskID(addr),0,blockID(addr));
  if(cache_enabled()){
    if(cache_lookup(diskID(addr), blockID(addr),tempBuf) == -1){
    jbod_operation(op,tempBuf);
    cache_insert(diskID(addr), blockID(addr), tempBuf);
    }
  }
  else{
    jbod_operation(op,tempBuf);
  }
  
  

  int currentDisk = diskID(addr);

  int incer;
  if(start + len < 256){
    incer = len;
  }
  else{
    incer = 256 - start;
  }

  memcpy(&wholeBuf[readBytes],&tempBuf[start], incer);
  readBytes += incer;

  addr += incer;

  
  
  //A while loop to loop through the rest of the blocks and disks in the len and copy information onto the whole buffer
  while(readBytes < len){
    //checks if a new disk is being used and will seek out the starting block in it
    if(currentDisk != diskID(addr)){
      uint32_t op = packedbytes(2,diskID(addr),0,blockID(addr));
      jbod_operation(op,NULL);
      op = packedbytes(3,diskID(addr),0,blockID(addr));
      jbod_operation(op,NULL);
      currentDisk++;
    }
    //checks if the end is not a full 256 block and will prevent overflow when memcpy to the whole buffer
    if(len - readBytes < 256){
      incer = len - readBytes;
    }
    else{
      incer = 256;
    }

    uint8_t tempBuf2[256];
    memset(tempBuf2, 0, 256);
    op = packedbytes(4,diskID(addr),0,blockID(addr));
    if(cache_enabled()){
      if(cache_lookup(diskID(addr), blockID(addr),tempBuf2) == -1){
      jbod_operation(op,tempBuf2);
      cache_insert(diskID(addr), blockID(addr), tempBuf2);
      }
    }
    else{
      jbod_operation(op,tempBuf2);
    }

    memcpy(&wholeBuf[readBytes],tempBuf2,incer);

    //increments readBytes and addr to keep track of placement in blocks and discs
    readBytes += incer;
    addr += incer;
  }
  //copies whole buffer onto the return buffer
  memcpy(buf, wholeBuf, len);

  
  
  return len;
}

int mdadm_write(uint32_t addr, uint32_t len, const uint8_t *buf){
  //restrictions
  if(len > 1024 || len < 0 || mounted == 0 ||addr < 0 || addr+len > (16*(256*256)) || (buf == NULL && len!=0)){
    return -1;
  }
  //memcopy write buffer into read buffer (messaging tubes, someone sends you a read through tube, you then scribble over it and send it back with write tube)

  
  
  
  //create incrementation variables and search for starting location in disks and blocks.
  int start = addr % 256;
  int readBytes = 0;
  uint32_t op = packedbytes(2,diskID(addr),0,blockID(addr));
  jbod_operation(op,NULL);
  op = packedbytes(3,diskID(addr),0,blockID(addr));
  jbod_operation(op,NULL);

  //created a tempbuf to act as the writting buffer that will be used to write later after the need information is copied into it.
  uint8_t tempBuf[256];
  memset(tempBuf, 0, 256);
  op = packedbytes(4,diskID(addr),0,blockID(addr));

  if(cache_enabled()){
    if(cache_lookup(diskID(addr), blockID(addr),tempBuf) == -1){
    jbod_operation(op,tempBuf);
    cache_insert(diskID(addr), blockID(addr), tempBuf);
    }
  }
  else{
    jbod_operation(op,tempBuf);
  }

  //seek again to prepare for writing
  op = packedbytes(3,diskID(addr),0,blockID(addr));
  jbod_operation(op,NULL);

  //track current disk to check if writing accross new disk
  int currentDisk = diskID(addr);

  //checks if it continues onto another buffer and will give a new length of whats left of the current buffer
  int incer;
  if(start + len < 256){
    incer = len;
  }
  else{
    incer = 256 - start;
  }
  
  //given tempbuf as a perfect buffer now we copy all the needed info from buf to the corresponding section in tempbuf.
  
  memcpy(&tempBuf[start],buf,incer);

  //write tempbuf to storage
  op = packedbytes(5,diskID(addr),0,blockID(addr));

  jbod_operation(op,tempBuf);

  if(cache_enabled()){
    cache_update(diskID(addr), blockID(addr), tempBuf);
  }

  addr += incer;
  readBytes += incer;

  //A while loop to loop through the rest of the blocks similar to the read function but will now read into a tempbuf and then copy the write buf into that temp, then it will seek then write temp to storage.
  while(readBytes < len){
    //checks if a new disk is being used and will seek out the starting block in it
    if(currentDisk != diskID(addr)){
      uint32_t op = packedbytes(2,diskID(addr),0,blockID(addr));
      jbod_operation(op,NULL);
      op = packedbytes(3,diskID(addr),0,blockID(addr));
      jbod_operation(op,NULL);
      currentDisk++;
    }
    //checks if the end is not a full 256 block and will prevent overflow when memcpy to the whole buffer
    if(len - readBytes < 256){
      incer = len - readBytes;
    }
    else{
      incer = 256;
    }

    uint8_t tempBuf2[256];
    memset(tempBuf2, 0, 256);
    op = packedbytes(4,diskID(addr),0,blockID(addr));
    if(cache_enabled()){
      if(cache_lookup(diskID(addr), blockID(addr),tempBuf2) == -1){
      jbod_operation(op,tempBuf2);
      cache_insert(diskID(addr), blockID(addr), tempBuf2);
      }
    }
    else{
      jbod_operation(op,tempBuf2);
    }
    //seek again after reading so write is in the correct section
    op = packedbytes(3,diskID(addr),0,blockID(addr));
    jbod_operation(op,NULL);

    //given tempbuf as a perfect buffer now we copy all the needed info from buf to the corresponding section in tempbuf.
    cache_insert(diskID(addr), blockID(addr), tempBuf2);
    memcpy(tempBuf2,&buf[readBytes],incer);

    //write tempbuf to storage
    op = packedbytes(5,diskID(addr),0,blockID(addr));

    jbod_operation(op,tempBuf2);

    if(cache_enabled()){
      cache_update(diskID(addr), blockID(addr), tempBuf2);
    }
    //increment readBytes based on how much bytes have been itterated through with the jbod operations to keep write on the correct section.
    readBytes += incer;
    addr += incer;
  }
  


  return len;
}
