#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "cache.h"



static cache_entry_t *cache = NULL;
static int cache_size = 0;
static int clock = 0;
static int num_queries = 0;
static int num_hits = 0;

//allocate memory for cache by using malloc so its is dynamically allocated and set cache_size to num_entries. 
int cache_create(int num_entries) {
  if (num_entries < 2 || num_entries > 4096 || cache_size != 0){
    return -1;
  }
  cache = (cache_entry_t *) malloc(num_entries * sizeof(cache_entry_t));
  cache_size = num_entries;
  
  return 1;
}

//clear allocated memory and set cache_size to 0
int cache_destroy(void) {
  if (cache_size == 0){
    return -1;
  }
  free(cache);
  cache = NULL;
  cache_size = 0;
  return 1;
}


int cache_lookup(int disk_num, int block_num, uint8_t *buf) {
  
  //checks for any invlaid paramaters and returns -1
  if(cache_enabled() == false || buf == NULL || disk_num > 16 || disk_num < 0 || block_num > 256 || block_num < 0){
    
    return -1;
  }
  //looks for any matching disk_num and block_num and checks if it is valid, it will update hit, clock, and queries if so.
  for(int i = 0; i < cache_size; i++){
    
    if(cache[i].disk_num == disk_num && cache[i].block_num == block_num){
      if(cache[i].valid == true){
        memcpy(buf, cache[i].block, 256);
        cache[i].access_time = clock;
        num_queries++;
        num_hits++;
        clock++;
        return 1;
      }
    }
  }
  num_queries++;
  return -1;
}

//looks for current disk_num and block_num in cache, if it finds it then it will update block with the buf
void cache_update(int disk_num, int block_num, const uint8_t *buf) {
  uint8_t tempBuf[256];
  if(cache_lookup(disk_num, block_num, tempBuf) == 1){
    for(int i = 0; i < cache_size; i++){
      if(cache[i].disk_num == disk_num && cache[i].block_num == block_num && cache[i].valid == true){
        memcpy(cache[i].block, buf, 256);
        cache[i].access_time = clock;
        clock++;
      }
    }
  }
}


int cache_insert(int disk_num, int block_num, const uint8_t *buf) {
  //checks for invalid parameters and returns -1 if found
  if(cache_enabled() == false || buf == NULL || disk_num > 16 || disk_num < 0 || block_num > 256 || block_num < 0){
   
    return -1;
  }
  //checks if cache entry is already in the cashe and will return -1 if true
  for(int i = 0; i < cache_size; i++){
    if(cache[i].valid == true){
      if(cache[i].disk_num == disk_num && cache[i].block_num == block_num){
        return -1;
      }
    }
  }
  //if it finds an invald(empty) entry then it will immedietly input the cache entry there
  for(int i = 0; i < cache_size; i++){
    if(cache[i].valid == false){
      memcpy(cache[i].block, buf, 256);
      cache[i].disk_num = disk_num;
      cache[i].block_num = block_num;
      cache[i].access_time = clock;
      cache[i].valid = true;
      clock++;
      return 1;
    }
  }
  //creates a for loop to check for lowest usage and will mark its index
  int minTime = cache[0].access_time;
  int index = 0;
  for(int i = 0; i < cache_size; i++){
    
    if(minTime > cache[i].access_time){
      minTime = cache[i].access_time;
      index = i;
    }
  }
  //uses index marked as lowest use and replaces current entry with new entry
  memcpy(cache[index].block, buf, 256);
  cache[index].disk_num = disk_num;
  cache[index].block_num = block_num;
  cache[index].access_time = clock;
  cache[index].valid = true;
  clock++;
  
  
  return 1;
}

//checks if cache is open and created
bool cache_enabled(void) {
  if(cache_size > 2){
    return true;
  }
  return false;
}
//calculates hit rate
void cache_print_hit_rate(void) {
  fprintf(stderr, "Hit rate: %5.1f%%\n", 100 * (float) num_hits / num_queries);
}
